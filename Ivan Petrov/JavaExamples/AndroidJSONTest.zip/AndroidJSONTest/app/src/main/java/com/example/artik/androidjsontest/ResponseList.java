package com.example.artik.androidjsontest;
import java.util.List;
import java.util.ArrayList;

public class ResponseList {
    private List<User> users = new ArrayList<User>();

    public List<User> getUsers() {
        return users;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }
}